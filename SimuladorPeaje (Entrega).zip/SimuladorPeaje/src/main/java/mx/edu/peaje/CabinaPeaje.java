package mx.edu.peaje;

import java.util.Random;

/** Cada objeto representa una cabina que se ejecuta en su propio hilo. */
public class CabinaPeaje implements Runnable {
    // Compartida intencionalmente sin protección, como exige la actividad.
    public static int totalRecaudadoGlobal = 0;

    private final String nombre;
    private int vehiculosAtendidos;
    private final int vehiculosAsignados;

    public CabinaPeaje(String nombre, int vehiculosAsignados) {
        if (nombre == null || nombre.isBlank() || vehiculosAsignados < 0) {
            throw new IllegalArgumentException("Nombre o cantidad de vehiculos invalidos.");
        }
        this.nombre = nombre;
        this.vehiculosAsignados = vehiculosAsignados;
        this.vehiculosAtendidos = 0;
    }

    @Override
    public void run() {
        Random aleatorio = new Random();
        for (int vehiculo = 1; vehiculo <= vehiculosAsignados; vehiculo++) {
            if (Thread.currentThread().isInterrupted()) return;
            int tiempoCobro = 500 + aleatorio.nextInt(1001);
            System.out.printf("[%s] Atendiendo vehiculo %02d/%02d | Cobro: %d ms%n",
                    nombre, vehiculo, vehiculosAsignados, tiempoCobro);
            try {
                Thread.sleep(tiempoCobro);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                System.out.printf("[%s] Atencion interrumpida.%n", nombre);
                return;
            }

            vehiculosAtendidos++;
            // Leer, sumar y escribir no es una operación atómica.
            // No se corrige esta condición de carrera: es parte del ejercicio.
            totalRecaudadoGlobal += 50;
            System.out.printf("[%s] Vehiculo %02d terminado | Cobrado: $50 | Atendidos: %d%n",
                    nombre, vehiculo, vehiculosAtendidos);
        }
        System.out.printf("[%s] Finalizo su trabajo.%n", nombre);
    }

    public String getNombre() { return nombre; }
    public int getVehiculosAtendidos() { return vehiculosAtendidos; }
}
