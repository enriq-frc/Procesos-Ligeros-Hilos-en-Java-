package mx.edu.peaje;

import java.util.Locale;
import java.util.Scanner;

/** Aplicación de consola: tres hilos atienden diez vehículos cada uno. */
public final class SimuladorPeaje {
    private SimuladorPeaje() { }

    public static void main(String[] args) {
        String apellido;
        if (args.length > 0) {
            apellido = String.join(" ", args).trim();
        } else {
            Scanner entrada = new Scanner(System.in);
            System.out.print("Escribe tu primer apellido: ");
            System.out.flush();
            if (!entrada.hasNextLine()) {
                System.err.println("Se necesita tu primer apellido para nombrar la primera cabina.");
                return;
            }
            apellido = entrada.nextLine().trim();
            while (apellido.isBlank()) {
                System.out.print("El apellido no puede estar vacío. Escríbelo: ");
                System.out.flush();
                if (!entrada.hasNextLine()) return;
                apellido = entrada.nextLine().trim();
            }
        }
        if (apellido.isBlank()) {
            System.err.println("El apellido no puede estar vacio.");
            return;
        }

        CabinaPeaje.totalRecaudadoGlobal = 0;
        CabinaPeaje[] cabinas = {
            new CabinaPeaje("Cabina " + apellido, 10),
            new CabinaPeaje("Cabina 2", 10),
            new CabinaPeaje("Cabina 3", 10)
        };
        Thread[] hilos = new Thread[cabinas.length];
        System.out.println("\n=== SIMULADOR DE PEAJE ===");
        System.out.println("3 cabinas | 10 vehiculos por cabina | Tarifa: $50");
        System.out.println("Total de vehiculos: 30 | Recaudacion esperada: $1500\n");
        long inicio = System.nanoTime();

        // Se inician TODOS los hilos antes de esperar a cualquiera.
        for (int i = 0; i < cabinas.length; i++) {
            hilos[i] = new Thread(cabinas[i], cabinas[i].getNombre());
            hilos[i].start();
        }
        try {
            for (Thread hilo : hilos) {
                hilo.join();
            }
        } catch (InterruptedException ex) {
            for (Thread hilo : hilos) hilo.interrupt();
            // Esperar el cierre de los trabajadores sin imprimir un reporte incompleto.
            for (Thread hilo : hilos) {
                boolean terminado = false;
                while (!terminado) {
                    try { hilo.join(); terminado = true; }
                    catch (InterruptedException nuevaInterrupcion) { hilo.interrupt(); }
                }
            }
            Thread.currentThread().interrupt();
            System.err.println("Simulacion cancelada por interrupcion.");
            return;
        }

        int totalVehiculos = 0;
        System.out.println("\n=== REPORTE FINAL ===");
        for (CabinaPeaje cabina : cabinas) {
            int atendidos = cabina.getVehiculosAtendidos();
            totalVehiculos += atendidos;
            System.out.printf("%s | Vehiculos atendidos: %d | Importe segun su contador: $%d%n",
                    cabina.getNombre(), atendidos, atendidos * 50);
        }
        int esperado = totalVehiculos * 50;
        int observado = CabinaPeaje.totalRecaudadoGlobal;
        System.out.println("Total de vehiculos atendidos: " + totalVehiculos);
        System.out.println("Recaudacion esperada según vehiculos: $" + esperado);
        System.out.println("totalRecaudadoGlobal: $" + observado);
        System.out.println("Diferencia (esperado - observado): $" + (esperado - observado));
        System.out.printf(Locale.ROOT, "Tiempo transcurrido: %.2f segundos%n",
                (System.nanoTime() - inicio) / 1_000_000_000.0);
        if (observado == esperado) {
            System.out.println("En esta ejecucion no se observo perdida de cobros.");
            System.out.println("Esto no garantiza que el contador compartido sea seguro.");
        } else {
            System.out.println("Se observo una discrepancia en el contador compartido sin proteccion.");
        }
    }
}
